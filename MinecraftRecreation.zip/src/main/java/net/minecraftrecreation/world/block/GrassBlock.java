package net.minecraftrecreation.world.block;

import net.minecraftrecreation.world.block.base.Block;

public class GrassBlock extends Block {
    @Override
    public String id() {
        return "grass_block";
    }
}
