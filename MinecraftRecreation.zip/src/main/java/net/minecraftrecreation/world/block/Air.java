package net.minecraftrecreation.world.block;

import net.minecraftrecreation.world.block.base.TexturelessBlock;

public class Air extends TexturelessBlock {
    @Override
    public String id() {
        return "air";
    }
}
